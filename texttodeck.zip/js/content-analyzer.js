/**
 * TextDeck — content-analyzer.js
 * ═══════════════════════════════════════════════════════
 * PHASE 1: Content Analysis Engine
 *
 * Detects:
 *   - Title candidates
 *   - Definitions
 *   - Bullet lists
 *   - Sections / Subsections
 *   - Timelines
 *   - Comparisons
 *   - Facts / Statistics
 *   - Paragraphs
 *   - Conclusions
 *
 * Output: { title, sections[], definitions[], lists[], paragraphs[], facts[] }
 *
 * Rules:
 *   - No HTML generation
 *   - No slide awareness
 *   - Pure content analysis only
 * ═══════════════════════════════════════════════════════
 */

const ContentAnalyzer = (() => {

  // ── REGEX PATTERNS ──────────────────────────────────────────────

  const PATTERNS = {
    // Definition markers (multilingual)
    definition: /\b(adalah|merupakan|ialah|yaitu|didefinisikan sebagai|refers to|is defined as|is a|is an|is the|was a|was an|was the|are the|were the)\b/i,

    // Bullet item markers
    bullet: /^[\s]*([-*•▸▹◦‣⁃]|\d+[.):]|[a-z][.):]|[ivxlcdm]+[.)])\s+/i,

    // Section header candidates
    sectionHeader: /^[\s]*(#{1,3}\s+|[A-Z\u00C0-\u024F][^.!?\n]{2,60})\s*[:：]?\s*$/,

    // Colon-terminated header
    colonHeader: /^([^:：]{3,50})[:：]\s*$/,

    // Timeline / year patterns
    timeline: /\b(1[5-9]\d{2}|20[0-2]\d)\b/,
    timelineStrong: /^[\s]*(1[5-9]\d{2}|20[0-2]\d)\s*[-–—:]/,

    // Statistic / number patterns
    statistic: /(\d+[.,]?\d*\s*(%|persen|percent|juta|miliar|billion|million|trillion|ribu|thousand|USD|EUR|IDR|\$|€|Rp)|\b\d{2,}[.,]\d+\b)/i,

    // Comparison keywords
    comparison: /\b(vs\.?|versus|dibandingkan|compared to|sedangkan|while|whereas|sementara|namun|however|but|on the other hand|sebaliknya)\b/i,

    // Conclusion / summary markers
    conclusion: /^[\s]*(kesimpulan|conclusion|summary|ringkasan|in conclusion|to summarize|sebagai kesimpulan|secara keseluruhan|overall|in summary|to sum up)\s*[:：]?\s*/i,

    // Fact markers
    fact: /\b(menurut|according to|berdasarkan|based on|data menunjukkan|research shows|studies show|fakta|fact|tercatat|recorded|diketahui)\b/i,

    // Empty / whitespace
    empty: /^\s*$/,

    // Markdown heading
    mdHeading: /^#{1,3}\s+(.+)$/,
  };

  // ── HELPER: Sentence segmentation ──────────────────────────────

  function splitSentences(text) {
    return text
      .split(/(?<=[.!?])\s+/)
      .map(s => s.trim())
      .filter(s => s.length > 0);
  }

  // ── HELPER: Is line a plausible title? ─────────────────────────

  function isTitleCandidate(line) {
    const stripped = line.replace(/^#{1,3}\s+/, '').trim();
    if (stripped.length < 2 || stripped.length > 80) return false;
    if (PATTERNS.bullet.test(line)) return false;
    if (stripped.endsWith('.') && stripped.split(/\s+/).length > 8) return false;
    // Short, no ending punctuation → likely a title
    if (stripped.split(/\s+/).length <= 10 && !/[.!?]$/.test(stripped)) return true;
    // Colon-terminated
    if (PATTERNS.colonHeader.test(line)) return true;
    // Markdown heading
    if (PATTERNS.mdHeading.test(line)) return true;
    return false;
  }

  // ── HELPER: Classify single line content type ──────────────────

  function classifyLine(line) {
    if (PATTERNS.empty.test(line)) return 'empty';
    if (PATTERNS.bullet.test(line)) return 'bullet';
    if (PATTERNS.conclusion.test(line)) return 'conclusion';
    if (PATTERNS.mdHeading.test(line)) return 'heading';
    if (PATTERNS.colonHeader.test(line)) return 'header';
    if (PATTERNS.definition.test(line)) return 'definition';
    if (PATTERNS.timelineStrong.test(line)) return 'timeline';
    if (isTitleCandidate(line)) return 'title';
    return 'paragraph';
  }

  // ── HELPER: Clean bullet text ──────────────────────────────────

  function cleanBullet(line) {
    return line.replace(PATTERNS.bullet, '').trim();
  }

  // ── HELPER: Clean heading text ─────────────────────────────────

  function cleanHeading(line) {
    // Remove markdown hashes
    let cleaned = line.replace(/^#{1,3}\s+/, '').trim();
    // Remove trailing colon
    cleaned = cleaned.replace(/[:：]\s*$/, '').trim();
    return cleaned;
  }

  // ── HELPER: Extract definition pair ────────────────────────────

  function extractDefinition(line) {
    const match = line.match(PATTERNS.definition);
    if (!match) return null;
    const idx = line.search(PATTERNS.definition);
    const term = line.slice(0, idx).trim();
    const meaning = line.slice(idx + match[0].length).trim()
      .replace(/[.。]$/, '');
    if (!term || !meaning) return null;
    return { term, meaning };
  }

  // ── HELPER: Detect facts/statistics in text ────────────────────

  function extractFacts(text) {
    const facts = [];
    const sentences = splitSentences(text);
    for (const sent of sentences) {
      if (PATTERNS.statistic.test(sent) || PATTERNS.fact.test(sent)) {
        facts.push(sent.trim());
      }
    }
    return facts;
  }

  // ── HELPER: Has comparison content? ────────────────────────────

  function hasComparison(text) {
    return PATTERNS.comparison.test(text);
  }

  // ── HELPER: Has timeline content? ──────────────────────────────

  function hasTimeline(text) {
    return PATTERNS.timeline.test(text);
  }

  // ── MAIN ANALYSIS FUNCTION ─────────────────────────────────────

  /**
   * Analyze raw text and produce structured content analysis.
   *
   * @param {string} rawText — The input text
   * @returns {{ title: string, sections: Array, definitions: Array,
   *             lists: Array, paragraphs: Array, facts: Array,
   *             hasTimeline: boolean, hasComparison: boolean,
   *             conclusionText: string|null }}
   */
  function analyze(rawText) {
    if (!rawText || typeof rawText !== 'string') {
      return {
        title: 'Untitled',
        sections: [],
        definitions: [],
        lists: [],
        paragraphs: [],
        facts: [],
        hasTimeline: false,
        hasComparison: false,
        conclusionText: null,
      };
    }

    const lines = rawText.split('\n');
    const result = {
      title: '',
      sections: [],
      definitions: [],
      lists: [],
      paragraphs: [],
      facts: [],
      hasTimeline: false,
      hasComparison: false,
      conclusionText: null,
    };

    // ── Pass 1: Line classification ────────────────────────────
    const classified = lines.map((raw, i) => ({
      index: i,
      raw: raw,
      text: raw.trim(),
      type: classifyLine(raw.trim()),
    }));

    // ── Pass 2: Extract deck title ─────────────────────────────
    // First heading or first title-candidate line
    const titleLine = classified.find(
      l => l.type === 'heading' || l.type === 'title' || l.type === 'definition'
    );

    if (titleLine) {
      if (titleLine.type === 'heading') {
        result.title = cleanHeading(titleLine.text);
      } else if (titleLine.type === 'definition') {
        const def = extractDefinition(titleLine.text);
        result.title = def ? def.term : titleLine.text.split(/\s+/).slice(0, 5).join(' ');
      } else {
        result.title = cleanHeading(titleLine.text);
      }
    } else {
      // Fallback: first non-empty line
      const firstLine = classified.find(l => l.type !== 'empty');
      result.title = firstLine
        ? firstLine.text.split(/\s+/).slice(0, 6).join(' ')
        : 'Untitled';
    }

    // ── Pass 3: Group into sections ────────────────────────────
    let currentSection = null;
    let currentBullets = [];
    let isAfterTitle = false;
    let pendingParagraph = [];

    function flushBullets() {
      if (!currentBullets.length) return;
      const list = {
        heading: currentSection ? currentSection.heading : 'Key Points',
        items: [...currentBullets],
      };
      result.lists.push(list);

      if (currentSection) {
        currentSection.content.push({
          type: 'list',
          items: [...currentBullets],
        });
      }
      currentBullets = [];
    }

    function flushParagraph() {
      if (!pendingParagraph.length) return;
      const text = pendingParagraph.join(' ').trim();
      if (!text) { pendingParagraph = []; return; }

      // Extract facts from paragraph
      const parFacts = extractFacts(text);
      if (parFacts.length) result.facts.push(...parFacts);

      // Detect comparison
      if (hasComparison(text)) result.hasComparison = true;

      // Detect timeline
      if (hasTimeline(text)) result.hasTimeline = true;

      const paragraph = {
        text,
        wordCount: text.split(/\s+/).length,
        sectionHeading: currentSection ? currentSection.heading : null,
      };
      result.paragraphs.push(paragraph);

      if (currentSection) {
        currentSection.content.push({
          type: 'paragraph',
          text,
          wordCount: paragraph.wordCount,
        });
      }
      pendingParagraph = [];
    }

    for (let i = 0; i < classified.length; i++) {
      const line = classified[i];

      // Skip the first title line (already used as deck title)
      if (i === 0 && titleLine && line.index === titleLine.index) {
        // If it's a definition, still record it
        if (line.type === 'definition') {
          const def = extractDefinition(line.text);
          if (def) result.definitions.push(def);
        }
        isAfterTitle = true;
        continue;
      }

      switch (line.type) {
        case 'empty':
          flushParagraph();
          break;

        case 'heading':
        case 'header':
          flushBullets();
          flushParagraph();
          currentSection = {
            heading: cleanHeading(line.text),
            content: [],
            lineIndex: i,
          };
          result.sections.push(currentSection);
          break;

        case 'title':
          // A short line after content = potential new section
          flushBullets();
          flushParagraph();
          currentSection = {
            heading: cleanHeading(line.text),
            content: [],
            lineIndex: i,
          };
          result.sections.push(currentSection);
          break;

        case 'definition': {
          flushBullets();
          flushParagraph();
          const def = extractDefinition(line.text);
          if (def) {
            result.definitions.push(def);
            if (currentSection) {
              currentSection.content.push({
                type: 'definition',
                term: def.term,
                meaning: def.meaning,
              });
            }
          } else {
            pendingParagraph.push(line.text);
          }
          break;
        }

        case 'bullet': {
          flushParagraph();
          const clean = cleanBullet(line.text);
          if (clean) currentBullets.push(clean);

          // If no current section, create an implicit one
          if (!currentSection) {
            currentSection = {
              heading: 'Key Points',
              content: [],
              lineIndex: i,
            };
            result.sections.push(currentSection);
          }
          break;
        }

        case 'timeline': {
          flushBullets();
          flushParagraph();
          result.hasTimeline = true;

          if (!currentSection) {
            currentSection = {
              heading: 'Timeline',
              content: [],
              lineIndex: i,
            };
            result.sections.push(currentSection);
          }
          currentSection.content.push({
            type: 'timeline-entry',
            text: line.text,
          });
          break;
        }

        case 'conclusion':
          flushBullets();
          flushParagraph();
          // Gather remaining lines as conclusion
          const conclusionParts = [line.text.replace(PATTERNS.conclusion, '').trim()];
          let j = i + 1;
          while (j < classified.length) {
            if (classified[j].type === 'empty' && j - i > 1) break;
            if (classified[j].type !== 'empty') {
              conclusionParts.push(classified[j].text);
            }
            j++;
          }
          result.conclusionText = conclusionParts.filter(Boolean).join(' ').trim();
          i = j - 1; // Skip consumed lines
          break;

        case 'paragraph':
        default:
          flushBullets();
          pendingParagraph.push(line.text);
          break;
      }
    }

    // Final flush
    flushBullets();
    flushParagraph();

    // ── Pass 4: Deduplicate facts ──────────────────────────────
    result.facts = [...new Set(result.facts)];

    return result;
  }

  // ── PUBLIC API ──────────────────────────────────────────────────

  return { analyze };

})();
