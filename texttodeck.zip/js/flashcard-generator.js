/**
 * TextDeck — flashcard-generator.js
 * ═══════════════════════════════════════════════════════
 * PHASE 5: Independent Flashcard Generation Pipeline
 *
 * Flow:
 *   Text → Analyzer → Definition Extractor → Flashcard Generator → Render
 *
 * Completely independent from presentation pipeline.
 * Does NOT reuse presentation rendering logic.
 *
 * Exports: FlashcardGenerator.generate(rawText)
 * ═══════════════════════════════════════════════════════
 */

const FlashcardGenerator = (() => {

  const MAX_ANSWER_WORDS = 40;

  /**
   * Generate flashcards from raw text.
   * Uses ContentAnalyzer for analysis, then independently
   * produces flashcard data.
   *
   * @param {string} rawText — Source text
   * @returns {Array<{ type: 'flashcard', front: string, back: string, category: string }>}
   */
  function generate(rawText) {
    if (!rawText || typeof rawText !== 'string') return [];

    const analysis = ContentAnalyzer.analyze(rawText);
    const cards = [];

    // ── 1. Definitions → Question/Answer cards ─────────────────
    for (const def of (analysis.definitions || [])) {
      if (def.term && def.meaning) {
        cards.push({
          type: 'flashcard',
          front: `What is ${def.term}?`,
          back: capitalize(def.meaning),
          category: 'definition',
        });
      }
    }

    // ── 2. Sections with bullets → Topic/Details cards ─────────
    for (const section of (analysis.sections || [])) {
      const lists = (section.content || []).filter(c => c.type === 'list');
      for (const list of lists) {
        if (list.items && list.items.length > 0) {
          cards.push({
            type: 'flashcard',
            front: section.heading || 'Key Points',
            back: formatBulletAnswer(list.items),
            category: 'list',
          });
        }
      }

      // Paragraphs within sections → Key concept cards
      const paragraphs = (section.content || []).filter(c => c.type === 'paragraph');
      for (const para of paragraphs) {
        if (para.text && para.wordCount > 8) {
          const summary = Summarizer.summarize(para.text, MAX_ANSWER_WORDS);
          cards.push({
            type: 'flashcard',
            front: section.heading
              ? `Explain: ${section.heading}`
              : `Key Concept`,
            back: summary,
            category: 'concept',
          });
        }
      }

      // Definitions within sections
      const defs = (section.content || []).filter(c => c.type === 'definition');
      for (const def of defs) {
        // Avoid duplicates with top-level definitions
        const isDuplicate = cards.some(
          c => c.category === 'definition' && c.front.includes(def.term)
        );
        if (!isDuplicate && def.term && def.meaning) {
          cards.push({
            type: 'flashcard',
            front: `What is ${def.term}?`,
            back: capitalize(def.meaning),
            category: 'definition',
          });
        }
      }
    }

    // ── 3. Facts → True/False style cards ──────────────────────
    for (const fact of (analysis.facts || [])) {
      if (fact.length > 15) {
        const isDuplicate = cards.some(c => c.back.includes(fact.slice(0, 30)));
        if (!isDuplicate) {
          cards.push({
            type: 'flashcard',
            front: `Key Fact`,
            back: Summarizer.truncate(fact, MAX_ANSWER_WORDS),
            category: 'fact',
          });
        }
      }
    }

    // ── 4. Conclusion → Summary card ───────────────────────────
    if (analysis.conclusionText) {
      cards.push({
        type: 'flashcard',
        front: 'Summary / Conclusion',
        back: Summarizer.summarize(analysis.conclusionText, MAX_ANSWER_WORDS),
        category: 'conclusion',
      });
    }

    // ── 5. Fallback: If no cards generated, create basic ones ──
    if (cards.length === 0 && analysis.paragraphs && analysis.paragraphs.length > 0) {
      for (const para of analysis.paragraphs.slice(0, 5)) {
        const summary = Summarizer.summarize(para.text, MAX_ANSWER_WORDS);
        cards.push({
          type: 'flashcard',
          front: analysis.title || 'Key Point',
          back: summary,
          category: 'concept',
        });
      }
    }

    return deduplicateCards(cards);
  }

  // ── HELPERS ─────────────────────────────────────────────────────

  function formatBulletAnswer(items) {
    return items
      .slice(0, 6)
      .map(item => `• ${item}`)
      .join('\n');
  }

  function capitalize(text) {
    if (!text) return '';
    return text.charAt(0).toUpperCase() + text.slice(1);
  }

  function deduplicateCards(cards) {
    const seen = new Set();
    return cards.filter(card => {
      const key = (card.front + '|' + card.back).toLowerCase().slice(0, 100);
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });
  }

  // ── PUBLIC API ──────────────────────────────────────────────────

  return { generate };

})();
