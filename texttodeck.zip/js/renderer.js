/**
 * TextDeck — renderer.js
 * Phase 9: Pure Renderers — No business logic inside.
 *
 * Renders:
 *   renderTitleSlide(), renderContentSlide(), renderBulletSlide(),
 *   renderTimelineSlide(), renderComparisonSlide(), renderSummarySlide(),
 *   renderConclusionSlide(), renderFlashcard()
 */

const SlideRenderer = (() => {

  /* ── THEME PALETTES ──────────────────────────────────────────── */
  const THEMES = {
    futuristic: {
      bg: 'linear-gradient(135deg,#0a1628,#0d2040 60%,#0a2550)',
      color: '#fff',
      accent: '#00d1ff',
      accentBg: 'rgba(0,209,255,.12)',
      accentBorder: 'rgba(0,209,255,.3)',
      muted: 'rgba(255,255,255,.75)',
      cardBg: 'rgba(0,209,255,.06)',
      cardBorder: 'rgba(0,209,255,.18)',
      dotColor: '#00d1ff',
      ff: 'background:linear-gradient(135deg,#0d2040,#0a2550);border:1px solid rgba(0,209,255,.25);color:#fff;',
      fb: 'background:rgba(0,209,255,.1);border:1px solid rgba(0,209,255,.3);color:#fff;',
    },
    corporate: {
      bg: '#ffffff',
      color: '#131b2e',
      accent: '#0061a3',
      accentBg: '#e8f0fe',
      accentBorder: '#0061a3',
      muted: '#283044',
      cardBg: '#f0f4fa',
      cardBorder: 'rgba(0,97,163,.2)',
      dotColor: '#0061a3',
      ff: 'background:#f8fafc;border:2px solid #0061a3;color:#131b2e;',
      fb: 'background:#e8f0fe;border:2px solid #0061a3;color:#131b2e;',
    },
    creative: {
      bg: 'linear-gradient(135deg,#7c3aed,#db2777 50%,#f59e0b)',
      color: '#fff',
      accent: '#fbbf24',
      accentBg: 'rgba(255,255,255,.15)',
      accentBorder: 'rgba(255,255,255,.3)',
      muted: 'rgba(255,255,255,.85)',
      cardBg: 'rgba(255,255,255,.08)',
      cardBorder: 'rgba(255,255,255,.15)',
      dotColor: '#fff',
      ff: 'background:rgba(124,58,237,.8);border:1px solid rgba(255,255,255,.3);color:#fff;',
      fb: 'background:rgba(219,39,119,.7);border:1px solid rgba(255,255,255,.3);color:#fff;',
    },
    dark: {
      bg: 'linear-gradient(160deg,#0f1117,#1a1f2e)',
      color: '#e2e8f0',
      accent: '#34d399',
      accentBg: 'rgba(52,211,153,.1)',
      accentBorder: 'rgba(52,211,153,.25)',
      muted: '#94a3b8',
      cardBg: 'rgba(52,211,153,.05)',
      cardBorder: 'rgba(52,211,153,.15)',
      dotColor: '#34d399',
      ff: 'background:#1e2336;border:1px solid rgba(52,211,153,.2);color:#e2e8f0;',
      fb: 'background:rgba(52,211,153,.08);border:1px solid rgba(52,211,153,.25);color:#e2e8f0;',
    },
  };

  function t(themeId) { return THEMES[themeId] || THEMES.futuristic; }

  /* ── COMMON HELPERS ──────────────────────────────────────────── */

  function wrap(themeId, ratio, inner) {
    const th = t(themeId);
    const bgStyle = th.bg.includes('gradient') ? `background:${th.bg};` : `background:${th.bg};`;
    return `<div style="${bgStyle}color:${th.color};font-family:'Inter',sans-serif;aspect-ratio:${ratio || '16/9'};width:100%;box-sizing:border-box;overflow:hidden;display:flex;flex-direction:column;padding:clamp(24px,5%,48px);position:relative;">${inner}</div>`;
  }

  function badge(themeId, text) {
    if (!text) return '';
    const th = t(themeId);
    return `<div style="display:inline-block;padding:4px 14px;border-radius:999px;font-size:11px;font-weight:700;background:${th.accentBg};color:${th.accent};border:1px solid ${th.accentBorder};margin-bottom:16px;width:fit-content;letter-spacing:0.05em;">${text}</div>`;
  }

  function titleEl(themeId, text, size) {
    const th = t(themeId);
    const fs = size || 'clamp(18px,2.5vw,28px)';
    return `<div style="font-size:${fs};font-weight:800;color:${th.color};line-height:1.2;margin-bottom:10px;word-break:break-word;">${text || ''}</div>`;
  }

  function bodyEl(themeId, text) {
    if (!text) return '';
    const th = t(themeId);
    return `<p style="font-size:clamp(12px,1.4vw,15px);color:${th.muted};line-height:1.7;margin-bottom:14px;">${text}</p>`;
  }

  function bulletList(themeId, items) {
    if (!items || !items.length) return '';
    const th = t(themeId);
    return items.map(b => `
      <div style="display:flex;gap:10px;margin-bottom:8px;align-items:flex-start;">
        <span style="display:inline-block;width:7px;height:7px;border-radius:50%;background:${th.dotColor};flex-shrink:0;margin-top:7px;"></span>
        <span style="font-size:14px;color:${th.muted};line-height:1.6;">${b}</span>
      </div>
    `).join('');
  }

  function numberedList(themeId, items) {
    if (!items || !items.length) return '';
    const th = t(themeId);
    return items.map((b, i) => `
      <div style="display:flex;gap:14px;margin-bottom:10px;align-items:flex-start;">
        <span style="font-weight:800;color:${th.accent};font-size:15px;min-width:24px;flex-shrink:0;">${String(i+1).padStart(2,'0')}</span>
        <span style="font-size:14px;color:${th.muted};line-height:1.6;">${b}</span>
      </div>
    `).join('');
  }

  /* ── LAYOUT RENDERERS ────────────────────────────────────────── */

  function renderTitleCenter(slide, themeId, ratio) {
    const th = t(themeId);
    return wrap(themeId, ratio, `
      <div style="flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;">
        ${badge(themeId, slide.badge || slide.templateId?.toUpperCase())}
        <h1 style="font-size:clamp(24px,4vw,42px);font-weight:900;color:${th.color};line-height:1.15;margin-bottom:14px;max-width:85%;">${slide.title || ''}</h1>
        ${slide.subtitle ? `<p style="font-size:clamp(13px,1.6vw,17px);color:${th.muted};max-width:70%;line-height:1.55;">${slide.subtitle}</p>` : ''}
        ${slide.body && !slide.subtitle ? `<p style="font-size:clamp(13px,1.6vw,17px);color:${th.muted};max-width:70%;line-height:1.55;">${slide.body}</p>` : ''}
      </div>
    `);
  }

  function renderTitleBody(slide, themeId, ratio) {
    return wrap(themeId, ratio, `
      ${badge(themeId, slide.badge || slide.templateId?.toUpperCase())}
      <div style="flex:1;display:flex;flex-direction:column;justify-content:center;">
        ${titleEl(themeId, slide.title)}
        ${bodyEl(themeId, slide.body)}
      </div>
    `);
  }

  function renderTitleBullets(slide, themeId, ratio) {
    return wrap(themeId, ratio, `
      ${badge(themeId, slide.badge || slide.templateId?.toUpperCase())}
      ${titleEl(themeId, slide.title)}
      ${slide.body ? bodyEl(themeId, slide.body) : ''}
      <div style="flex:1;overflow:hidden;margin-top:4px;">
        ${bulletList(themeId, slide.bullets)}
      </div>
    `);
  }

  function renderConcept(slide, themeId, ratio) {
    const th = t(themeId);
    return wrap(themeId, ratio, `
      ${badge(themeId, slide.badge || 'CORE CONCEPT')}
      <div style="flex:1;display:flex;flex-direction:column;justify-content:center;">
        <div style="font-size:11px;text-transform:uppercase;letter-spacing:1.5px;color:${th.accent};opacity:0.7;margin-bottom:6px;">Core Concept</div>
        ${titleEl(themeId, slide.title)}
        <div style="border-left:3px solid ${th.accent};padding-left:18px;margin-top:12px;">
          ${bodyEl(themeId, slide.body)}
        </div>
      </div>
    `);
  }

  function renderHero(slide, themeId, ratio) {
    const th = t(themeId);
    return wrap(themeId, ratio, `
      <div style="flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;">
        <h1 style="font-size:clamp(22px,3.8vw,40px);font-weight:900;color:${th.color};line-height:1.12;margin-bottom:16px;max-width:90%;">${slide.title || ''}</h1>
        ${slide.body ? `<p style="font-size:clamp(13px,1.8vw,18px);max-width:80%;color:${th.muted};line-height:1.55;">${slide.body}</p>` : ''}
        ${slide.subtitle ? `<p style="font-size:clamp(13px,1.6vw,16px);max-width:80%;color:${th.muted};line-height:1.5;margin-top:8px;">${slide.subtitle}</p>` : ''}
      </div>
    `);
  }

  function renderHeroBody(slide, themeId, ratio) {
    const th = t(themeId);
    return wrap(themeId, ratio, `
      <div style="flex:1;display:flex;flex-direction:column;justify-content:center;">
        <h2 style="font-size:clamp(20px,3vw,32px);font-weight:900;margin-bottom:16px;color:${th.color};">${slide.title || ''}</h2>
        ${bodyEl(themeId, slide.body)}
      </div>
    `);
  }

  function renderCardGrid(slide, themeId, ratio) {
    const th = t(themeId);
    const items = slide.bullets || [];
    return wrap(themeId, ratio, `
      ${badge(themeId, slide.badge)}
      ${titleEl(themeId, slide.title, 'clamp(16px,2.2vw,24px)')}
      <div style="flex:1;display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:10px;margin-top:8px;align-content:start;">
        ${items.map(b => `
          <div style="background:${th.cardBg};padding:14px 16px;border-radius:12px;border:1px solid ${th.cardBorder};">
            <div style="font-weight:700;margin-bottom:3px;color:${th.accent};font-size:12px;">💡 Key Point</div>
            <div style="font-size:13px;color:${th.muted};line-height:1.5;">${b}</div>
          </div>
        `).join('')}
      </div>
    `);
  }

  function renderNumberedList(slide, themeId, ratio) {
    return wrap(themeId, ratio, `
      ${badge(themeId, slide.badge)}
      ${titleEl(themeId, slide.title)}
      <div style="flex:1;overflow:hidden;margin-top:8px;">
        ${numberedList(themeId, slide.bullets)}
      </div>
    `);
  }

  function renderTimelineVisual(slide, themeId, ratio) {
    const th = t(themeId);
    const items = slide.bullets || slide.items || [];
    return wrap(themeId, ratio, `
      ${badge(themeId, slide.badge || 'TIMELINE')}
      ${titleEl(themeId, slide.title)}
      <div style="flex:1;display:flex;flex-direction:column;gap:10px;margin-top:8px;padding-left:12px;border-left:2px dashed ${th.accentBorder};position:relative;">
        ${items.map(item => `
          <div style="display:flex;gap:12px;align-items:flex-start;position:relative;">
            <div style="position:absolute;left:-18px;top:5px;width:10px;height:10px;border-radius:50%;background:${th.accent};"></div>
            <span style="font-size:13px;color:${th.muted};line-height:1.6;padding-left:6px;">${item}</span>
          </div>
        `).join('')}
      </div>
    `);
  }

  function renderTimelineItem(slide, themeId, ratio) {
    const th = t(themeId);
    return wrap(themeId, ratio, `
      ${badge(themeId, slide.badge)}
      <div style="flex:1;display:flex;flex-direction:column;justify-content:center;">
        ${titleEl(themeId, '📍 ' + (slide.title || ''))}
        <div style="margin-top:12px;padding-left:20px;border-left:2px dashed ${th.accentBorder};position:relative;">
          <div style="position:absolute;left:-6px;top:6px;width:10px;height:10px;border-radius:50%;background:${th.accent};"></div>
          ${bodyEl(themeId, slide.body)}
        </div>
      </div>
    `);
  }

  function renderTwoColumn(slide, themeId, ratio) {
    const th = t(themeId);
    const left = slide.bulletsLeft || (slide.bullets || []).slice(0, Math.ceil((slide.bullets||[]).length/2));
    const right = slide.bulletsRight || (slide.bullets || []).slice(Math.ceil((slide.bullets||[]).length/2));
    return wrap(themeId, ratio, `
      ${badge(themeId, slide.badge)}
      ${titleEl(themeId, slide.title)}
      <div style="flex:1;display:flex;gap:24px;margin-top:8px;">
        <div style="flex:1;">
          <div style="font-size:10px;font-weight:700;opacity:0.5;margin-bottom:8px;text-transform:uppercase;letter-spacing:1px;">Group A</div>
          ${bulletList(themeId, left)}
        </div>
        <div style="width:1px;background:${th.accentBorder};"></div>
        <div style="flex:1;">
          <div style="font-size:10px;font-weight:700;opacity:0.5;margin-bottom:8px;text-transform:uppercase;letter-spacing:1px;">Group B</div>
          ${bulletList(themeId, right)}
        </div>
      </div>
    `);
  }

  function renderSplit(slide, themeId, ratio) {
    const th = t(themeId);
    return wrap(themeId, ratio, `
      ${badge(themeId, slide.badge)}
      <div style="flex:1;display:flex;gap:20px;align-items:stretch;">
        <div style="flex:1;background:${th.cardBg};padding:20px;border-radius:14px;border:1px solid ${th.cardBorder};display:flex;flex-direction:column;justify-content:center;">
          <h3 style="font-weight:800;font-size:clamp(16px,2vw,20px);color:${th.accent};margin-bottom:6px;">${slide.title || ''}</h3>
        </div>
        <div style="flex:1.5;display:flex;align-items:center;padding:12px;">
          ${bodyEl(themeId, slide.body)}
        </div>
      </div>
    `);
  }

  /* ── FLASHCARD RENDERER ──────────────────────────────────────── */

  function renderFlashcard(card, themeId, ratio) {
    const th = t(themeId);
    const bgStyle = th.bg.includes('gradient') ? `background:${th.bg};` : `background:${th.bg};`;
    const fcId = 'fc_' + Math.random().toString(36).slice(2, 7);
    const backText = (card.back || '').replace(/\n/g, '<br/>');
    return `
      <div style="${bgStyle}color:${th.color};font-family:'Inter',sans-serif;aspect-ratio:${ratio || '16/9'};width:100%;box-sizing:border-box;overflow:hidden;display:flex;align-items:center;justify-content:center;">
        <style>
          #${fcId}{width:85%;max-width:500px;cursor:pointer;perspective:1200px;height:70%;}
          #${fcId} .fc-inner{position:relative;width:100%;height:100%;transform-style:preserve-3d;transition:transform .5s ease;}
          #${fcId}.flipped .fc-inner{transform:rotateY(180deg);}
          #${fcId} .fc-front,#${fcId} .fc-back{position:absolute;inset:0;border-radius:16px;padding:28px;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;backface-visibility:hidden;box-shadow:0 10px 25px rgba(0,0,0,0.2);}
          #${fcId} .fc-back{transform:rotateY(180deg);}
        </style>
        <div id="${fcId}" onclick="this.classList.toggle('flipped')">
          <div class="fc-inner">
            <div class="fc-front" style="${th.ff}">
              ${badge(themeId, card.category ? card.category.toUpperCase() : 'QUESTION')}
              <div style="font-size:clamp(16px,2.2vw,24px);font-weight:800;line-height:1.3;margin-bottom:8px;">${card.front || ''}</div>
              <p style="font-size:11px;color:${th.muted};opacity:0.6;margin-top:10px;">Tap to reveal answer →</p>
            </div>
            <div class="fc-back" style="${th.fb}">
              ${badge(themeId, 'ANSWER')}
              <div style="font-size:clamp(13px,1.5vw,16px);line-height:1.65;font-weight:500;">${backText}</div>
            </div>
          </div>
        </div>
      </div>
    `;
  }

  /* ── MAIN DISPATCH ───────────────────────────────────────────── */

  const LAYOUT_MAP = {
    'title-center':     renderTitleCenter,
    'title-body':       renderTitleBody,
    'title-bullets':    renderTitleBullets,
    'concept':          renderConcept,
    'hero':             renderHero,
    'hero-body':        renderHeroBody,
    'card-grid':        renderCardGrid,
    'numbered-list':    renderNumberedList,
    'timeline-visual':  renderTimelineVisual,
    'timeline-item':    renderTimelineItem,
    'two-column':       renderTwoColumn,
    'split':            renderSplit,
  };

  function render(slide, themeId, ratio) {
    if (slide.type === 'flashcard') return renderFlashcard(slide, themeId, ratio);
    const fn = LAYOUT_MAP[slide.layout] || renderTitleBody;
    return fn(slide, themeId, ratio);
  }

  return { render, renderFlashcard };
})();
